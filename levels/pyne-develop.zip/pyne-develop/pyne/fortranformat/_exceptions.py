
class InvalidFormat(Exception):
    pass
