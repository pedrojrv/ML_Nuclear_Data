**Added:** None

**Changed:**

* ``rxname.child()`` and ``rxname.parent()`` now accept ``str`` for the
  ``z`` argument in Python 3.

**Deprecated:** None

**Removed:** None

**Fixed:** None

**Security:** None
