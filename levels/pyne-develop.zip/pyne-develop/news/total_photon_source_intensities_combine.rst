**Added:** None

**Changed:** 

* Combine the subvoxel/voxel R2S loops to calculate the total photon source intensities.

**Deprecated:** None

**Removed:** None

**Fixed:** None

**Security:** None
