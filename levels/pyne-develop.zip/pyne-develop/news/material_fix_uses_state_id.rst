**Added:**

* Adds tests to tests/test:materials.py:test_decay_heat(self) to check more isotopes

**Changed:**

* decay_heat() in material.cpp now calls metastable_id to convert zas_id to state_id

**Deprecated:** None

**Removed:** None

**Fixed:** None

**Security:** None
