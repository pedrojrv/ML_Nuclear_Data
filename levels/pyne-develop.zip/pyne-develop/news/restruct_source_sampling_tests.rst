**Added:** 

* An test function template that chould be used for different modes, geometries, src_tags, e_bounds, and bias_tags

* Several support functions for the test function template

* An example of using this the template to do the tests

**Changed:** None

**Deprecated:** None

**Removed:** None

**Fixed:** None

**Security:** None
