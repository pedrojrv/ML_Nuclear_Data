**Added:** None

**Changed:**

* Use new sampler for both voxel and sub-voxel R2S.

**Deprecated:** None

**Removed:** None

**Fixed:** None

**Security:** None
