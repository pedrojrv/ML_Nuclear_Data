**Added:** None

**Changed:** 

* Add input units check to the function utils.py/to_sec
* Use function utils.py/to_sec to replace alara.py/_TO_SEC

**Deprecated:** None

**Removed:** None

**Fixed:** None

**Security:** None
