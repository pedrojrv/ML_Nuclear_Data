**Added:**

* Add the ability to allow user turn off the void rejection in source sampling.

**Changed:** None

**Deprecated:** None

**Removed:** None

**Fixed:** None

**Security:** None
