**Added:** 

* Check for bias_tag data. Report error when bias tag data are all zero

* A test function to test the check

**Changed:** None

**Deprecated:** None

**Removed:** None

**Fixed:** None

**Security:** None
