**Added:** None
* script and CI implementation ensuring at least 1 news file have been recreated

**Changed:** None

**Deprecated:** None

**Removed:** None

**Fixed:** None

**Security:** None
