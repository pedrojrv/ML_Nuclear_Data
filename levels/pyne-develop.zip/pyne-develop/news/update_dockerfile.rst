**Added:** None

* Add options to install OpenMC Python API

**Changed:**

* Change the repo from cnerg/pyne to pyne/pyne

**Deprecated:** None

**Removed:** None

**Fixed:** None

**Security:** None
