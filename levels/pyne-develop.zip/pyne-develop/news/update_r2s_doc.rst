**Added:** None

**Changed:** 

* Documentation of R2S source_sampling method. Add descriptions about subvoxel R2S.

**Deprecated:** None

**Removed:** None

**Fixed:** None

**Security:** None
