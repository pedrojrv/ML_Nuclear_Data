**Added:**

* Check for the existence of the e_bounds file. Print error message when it's missing.

**Changed:** None

**Deprecated:** None

**Removed:** None

**Fixed:** None

**Security:** None
