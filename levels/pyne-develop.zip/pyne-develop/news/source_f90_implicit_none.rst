**Added:**

* MCNP6 version of source.F90

**Changed:**

* Changed source.F90 to use "implicit none" instead of "implicit real"

**Deprecated:** None

**Removed:** None

**Fixed:** None

**Security:** None
