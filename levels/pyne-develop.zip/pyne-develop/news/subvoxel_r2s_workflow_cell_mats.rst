**Added:** None

**Changed:** None

**Deprecated:** None

**Removed:** None

**Fixed:**

* Define cell_mats for subvoxel equals False

**Security:** None
