**Added:** None
- pyne::Material: capability to form PHITS input material card 
  
**Changed:** None

**Deprecated:** None

**Removed:** None

**Fixed:** None

**Security:** None
