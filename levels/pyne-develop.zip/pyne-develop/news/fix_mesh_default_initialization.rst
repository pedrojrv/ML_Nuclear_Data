**Added:** None

**Changed:** 

* Default initializer pyne.mesh.Mesh() now raises an exception with info on how to properly make a mesh

**Deprecated:** None

**Removed:** None

**Fixed:** None

**Security:** None
