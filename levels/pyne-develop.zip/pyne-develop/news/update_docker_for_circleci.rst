**Added:**

* Add hdf5-tools as dependency for docker images used in CircleCI, for better nose test comparing h5 files
* Add future as dependency for docker images used in CircleCI, for python2 and python3 compatibility

**Changed:** None

**Deprecated:** None

**Removed:** None

**Fixed:** None

**Security:** None
