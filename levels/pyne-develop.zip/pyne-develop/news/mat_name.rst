**Added:** None

**Changed:** None
- change openmc mat name reference from "mat_name" to "name"
**Deprecated:** None

**Removed:** None

**Fixed:** None

**Security:** None
