**Added:** None

**Changed:** None

**Deprecated:** None

**Removed:** None

**Fixed:** None
- new check won't now be triggered after a merge only on PRs

**Security:** None
