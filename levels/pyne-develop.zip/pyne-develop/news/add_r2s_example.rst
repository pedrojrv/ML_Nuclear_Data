**Added:** 

* R2S example files

**Changed:** 

* Update r2s documentation. Add example usage.

**Deprecated:** None

**Removed:** None

**Fixed:** None

**Security:** None
