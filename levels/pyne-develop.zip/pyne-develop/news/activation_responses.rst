**Added:**

* File scripts/activation_responses.py to get activation responses data for ALARA output file for better visualization
* File tests/test_activation_responses.py to test functions accoresponding to activation_responses.py
* Add support for decay heat
* Add support for specific activity
* Add support for alpha heat
* Add support for beta heat
* Add support for gamma heat
* Add support for wdr
* Add support for photon_source
* Add support for multiple response in one output.txt file

**Changed:** None

**Deprecated:** None

**Removed:** None

**Fixed:** None

**Security:** None
