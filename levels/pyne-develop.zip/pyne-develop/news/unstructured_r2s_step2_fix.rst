**Added:** None

**Changed:**

* Fix a problem of creating mesh from reading h5m files in unstructued R2S
* Update test function in test_r2s, allowing step2 run with the blank_mesh.h5m from step1

**Deprecated:** None

**Removed:** None

**Fixed:** None

**Security:** None
