**Added:** 

* Check 'cell_fracs' tag in source_sampling.cpp when sub_mode is DEFAULT. Prevent wrong use of source.h5m.

* Add test case to check wrong use of source.h5m.

**Changed:**

* Use mode names to change integers in the test_source_sampling.py

**Deprecated:** None

**Removed:** None

**Fixed:** None

**Security:** None
