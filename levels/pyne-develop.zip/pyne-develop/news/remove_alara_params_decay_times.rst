**Added:** None

**Changed:** 

* Read decay times from r2s config.ini, and then write them into alara_inp.

* Change some default names of alara_inp.

* Modify test funcitons of pyne/test_r2s.py.

**Deprecated:** None

**Removed:** 

* Decay times in the alara_params.txt.

**Fixed:** None

**Security:** None
