**Added:** 

* added gtcadis.py script
* first step for the GT-CADIS workflow, further steps to follow

**Changed:** None

**Deprecated:** None

**Removed:** None

**Fixed:** None

**Security:** None
