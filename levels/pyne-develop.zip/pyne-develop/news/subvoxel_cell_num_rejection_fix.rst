**Added:** None

**Changed:** 

* Change mode range of cell rejection from >3 to >2

**Deprecated:** None

**Removed:** None

**Fixed:** None

**Security:** None
