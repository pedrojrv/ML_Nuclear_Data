**Added:** None

**Changed:** None
- removed trailing space
- change tab for 2 spaces in all c++ files

**Deprecated:** None

**Removed:** None

**Fixed:** None

**Security:** None
