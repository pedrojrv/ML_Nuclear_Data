**Added:** None

**Changed:**

* Simplify the method to get the list of decay/cooling times

**Deprecated:** None

**Removed:** None

**Fixed:** None

**Security:** None
