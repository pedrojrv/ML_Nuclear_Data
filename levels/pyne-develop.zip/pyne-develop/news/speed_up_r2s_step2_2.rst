**Added:** None

**Changed:**

* In R2S step2, add option to write only 'total' to h5 file, reduce the CPU time

**Deprecated:** None

**Removed:** None

**Fixed:** None

**Security:** None
