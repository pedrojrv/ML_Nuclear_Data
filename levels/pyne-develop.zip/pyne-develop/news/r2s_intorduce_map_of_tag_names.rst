**Added:** 

* Constructor of Sampler using map<string, string> as an input parameter
* A test function to test the added constructor
* A test function to test input check of tag_names

**Changed:** None

**Deprecated:** None

**Removed:** None

**Fixed:** None

**Security:** None
