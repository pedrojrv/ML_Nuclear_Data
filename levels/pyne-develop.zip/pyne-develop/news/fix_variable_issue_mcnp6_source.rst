
**Added:** None

**Changed:**

* Removed variables ```icl_tmp``` and ```find_cell``` which are not longer needed. 

**Deprecated:** None

**Removed:** None

**Fixed:** None

**Security:** None
