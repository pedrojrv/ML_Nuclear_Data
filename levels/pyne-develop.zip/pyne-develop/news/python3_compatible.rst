**Added:**

* Add functions to do file, file block, line, and string almost the same
  compare functions in pyne/utils.py

**Changed:**

* Convert some code to enable python2/3 compatiblility
* Convert test function (including test_alara.py, test_mesh.py, test_dagmc.py,
  test_mcnp.py, test_partisn.py, test_r2s.py, test_source_sampling.py,
  test_variancereduction.py) to enable python2/3 compatibility.

**Deprecated:** None

**Removed:** None

**Fixed:** None

**Security:** None
