**Added:** None

**Changed:** None

**Deprecated:**

* Input check of cell_fracs tag under voxel mode. As the cell_fracs tag is there for voxel/sub-voxel mode.

**Removed:** None

**Fixed:** None

**Security:** None
