**Added:** None

**Changed:**

* Clean up some hard coded strings in test_source_sampling.py

**Deprecated:** None

**Removed:** None

**Fixed:** None

**Security:** None
