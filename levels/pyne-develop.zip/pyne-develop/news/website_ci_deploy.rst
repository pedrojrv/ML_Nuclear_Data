**Added:** None
- automatic deployement of a updated version of the website on tags
- automatic creation of a new version of the website (not deployed) for
  verication purposes in `pyne.github.com/website_preview`

**Changed:** None

**Deprecated:** None

**Removed:** None

**Fixed:** None

**Security:** None
