**Added:**

* A short description about "e_bounds" in the "source_sampling.rst"

**Changed:** None

**Deprecated:** None

**Removed:** None

**Fixed:** None

**Security:** None
