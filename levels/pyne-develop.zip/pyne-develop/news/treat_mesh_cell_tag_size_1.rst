**Added:**

* Add a test function to test for read cell_number_tag with size of 1

**Changed:** 

* Fix the problem of reading cell_number_tag with size of 1

**Deprecated:** None

**Removed:** None

**Fixed:** None

**Security:** None
