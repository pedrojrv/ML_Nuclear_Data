.. _gallery-data-sources:

Data Sources
==============

Download the :download:`full notebook <../../examples/data_sources.ipynb>`.

.. notebook:: ../../examples/data_sources.ipynb
