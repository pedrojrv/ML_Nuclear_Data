.. _gallery-mstar-vs-flowrate:

Erichment: M* vs Flowrate
==========================

Download the :download:`full notebook <../../examples/mstar_vs_flowrate.ipynb>`.

.. notebook:: ../../examples/mstar_vs_flowrate.ipynb
