.. _ubuntu:

=================================
Ubuntu build script
=================================

Scripts for installing PyNE and all its dependencies from scratch on Ubuntu
14.04 - 15.04 are found `here
<https://github.com/pyne/install_scripts/>`_.
