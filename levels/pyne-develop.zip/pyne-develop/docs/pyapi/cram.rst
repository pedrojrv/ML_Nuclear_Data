.. _pyne_cram:

==================================================
CRAM Solver (via Transmutagen) -- :mod:`pyne.cram`
==================================================

.. automodule:: pyne.cram
    :members:
