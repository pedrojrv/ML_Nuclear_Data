.. _pyne_fluka:

==========================================================
Fluka Output Interfaces -- :mod:`pyne.fluka`
==========================================================

.. currentmodule:: pyne.fluka

There is a class for processing output for Fluka.  The
functionality of the module can be obtained by importing as such::

    from pyne import fluka

Fluka API
--------

.. automodule:: pyne.fluka
    :members:  
