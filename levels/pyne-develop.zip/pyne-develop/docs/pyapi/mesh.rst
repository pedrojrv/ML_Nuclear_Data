.. _pyne_dbgen_mesh:

=================================================
PyNE Mesh -- :mod:`pyne.mesh`
=================================================

.. automodule:: pyne.mesh
    :members:
