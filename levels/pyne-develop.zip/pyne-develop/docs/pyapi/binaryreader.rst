.. _pyne_dbgen_binaryreader:

=================================================
Binary Reader -- :mod:`pyne.binaryreader`
=================================================

.. automodule:: pyne.binaryreader
    :members:
