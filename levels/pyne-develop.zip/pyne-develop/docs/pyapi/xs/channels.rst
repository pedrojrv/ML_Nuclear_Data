.. _pyne_xs_channels:

====================================================
Nuclear Reaction Channels -- :mod:`pyne.xs.channels`
====================================================

.. automodule:: pyne.xs.channels
    :members:
    :member-order: bysource
