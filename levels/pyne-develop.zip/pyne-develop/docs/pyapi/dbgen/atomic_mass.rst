.. _pyne_dbgen_stomic_mass:

============================================
Atomic Mass -- :mod:`pyne.dbgen.atomic_mass`
============================================

Atomic Mass API
---------------

.. automodule:: pyne.dbgen.atomic_mass
    :members:

