.. _pyne_partisn:

==========================================================
PARTISN Input and Output Interfaces -- :mod:`pyne.partisn`
==========================================================

.. currentmodule:: pyne.partisn

There is a module for processing input and output for PARTISN.  The
functionality of the module can be obtained by importing as such::

    from pyne import partisn

PARTISN API
--------

.. automodule:: pyne.partisn
    :members:  
