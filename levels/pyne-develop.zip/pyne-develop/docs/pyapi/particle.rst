.. _pyne_particle:

============================================
Particle Names -- :mod:`pyne.particle`
============================================
.. automodule:: pyne.particle
    :members:


Particle Listing
--------------------

.. include:: ../particle_listing
